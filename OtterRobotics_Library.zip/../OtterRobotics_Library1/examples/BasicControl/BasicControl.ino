/*
 * BasicControl.ino
 * 
 * Example sketch for the OtterRobotics library.
 * Demonstrates arm axis control and hand finger control.
 */

#include <OtterRobotics.h>

void setup() {
    // Initialize OtterRobotics (sets up Serial + UART1)
    OtterRobotics.begin(115200);

    delay(2000);

    // ─── Arm examples ─────────────────────────────────

    // Move axis 1 to 300 degrees  →  sends "SH1-300"
    Arm.moveAxis(1, 300);
    delay(3000);

    // Move axis 2 to 180 degrees  →  sends "SH2-180"
    Arm.moveAxis(2, 180);
    delay(3000);

    // Return all axes to home     →  sends SH1-190, SH2-240, SH3-200, SH4-200
    Arm.home();

    delay(2000);

    // ─── Hand examples ────────────────────────────────

    // Move finger 1 by 500 steps  →  sends "F1:500"
    Hand.moveFinger(1, 500);
    delay(3000);

    // Move finger 3 by 1000 steps →  sends "F3:1000"
    Hand.moveFinger(3, 1000);
    delay(3000);

    // Return all fingers to zero  →  sends F1:0 .. F6:0
    Hand.home();
}

void loop() {
    // Nothing here — all actions done in setup()
}
