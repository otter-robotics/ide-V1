# OtterRobotics

Arduino library for controlling a robotic arm (4 axes) and hand (6 fingers) via UART serial on ESP32.

## Installation

1. Download or clone this repository
2. Copy the `OtterRobotics` folder into your Arduino libraries directory:
   - **macOS**: `~/Documents/Arduino/libraries/`
   - **Windows**: `Documents\Arduino\libraries\`
   - **Linux**: `~/Arduino/libraries/`
3. Restart Arduino IDE

## Hardware Setup

- **ESP32** communicates with **Arduino Mega** via UART1
- TX pin: **21**, RX pin: **20**
- Baud rate: **115200**

## Quick Start

```cpp
#include <OtterRobotics.h>

void setup() {
    OtterRobotics.begin(115200);

    Arm.moveAxis(1, 300);   // sends "SH1-300"
    Hand.moveFinger(1, 500); // sends "F1:500"
}

void loop() {}
```

## API Reference

### `OtterRobotics.begin(baudRate)`
Initialize serial communication (USB + UART1).

---

### Arm

| Method | Description | Serial Command |
|--------|-------------|----------------|
| `Arm.moveAxis(axis, degree)` | Move axis (1–4) to degree (0–360) | `SH{axis}-{degree}` |
| `Arm.home()` | Return all axes to default position | `SH1-190`, `SH2-240`, `SH3-200`, `SH4-200` (6s delays) |

---

### Hand

| Method | Description | Serial Command |
|--------|-------------|----------------|
| `Hand.moveFinger(finger, steps)` | Move finger (1–6) by steps (0–1000) | `F{finger}:{steps}` |
| `Hand.home()` | Return all fingers to zero | `F1:0` … `F6:0` (4s delays) |

## Serial Protocol

| Command | Format | Example |
|---------|--------|---------|
| Move axis | `SH{1-4}-{0-360}` | `SH1-300` |
| Move finger | `F{1-6}:{0-1000}` | `F1:500` |

## License

MIT
