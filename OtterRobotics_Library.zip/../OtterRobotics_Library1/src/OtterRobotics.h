/*
 * OtterRobotics.h
 * 
 * Arduino library for Otter Robotics arm and hand control.
 * Communicates with Arduino Mega via UART1 (TX=21, RX=20).
 *
 * Author: Otter Robotics
 * License: MIT
 */

#ifndef OTTER_ROBOTICS_H
#define OTTER_ROBOTICS_H

#include <Arduino.h>
#include <HardwareSerial.h>

// ─── Forward declarations ────────────────────────────────────────────────────

class ArmController;
class HandController;

// ─── Main OtterRobotics class ────────────────────────────────────────────────

class OtterRoboticsClass {
public:
    OtterRoboticsClass();

    /**
     * Initialize serial communication.
     * Sets up USB Serial and UART1 (TX=21, RX=20) at the given baud rate.
     * 
     * @param baudRate  Baud rate for both Serial and UART1 (default 115200)
     */
    void begin(unsigned long baudRate = 115200);

    /**
     * Returns a pointer to the UART1 HardwareSerial used for communication.
     * Used internally by Arm and Hand controllers.
     */
    HardwareSerial* getSerial();

    /**
     * Check if the library has been initialized via begin().
     */
    bool isReady();

private:
    HardwareSerial _serial;
    bool _ready;
};

// ─── Arm controller ─────────────────────────────────────────────────────────

class ArmController {
public:
    ArmController();

    /**
     * Move a specific axis to the given degree.
     * Sends "SH{axis}-{degree}" over UART1.
     *
     * @param axis    Axis number (1–4)
     * @param degree  Target angle  (0–360)
     * @return true on success, false if parameters are out of range
     */
    bool moveAxis(uint8_t axis, uint16_t degree);

    /**
     * Return all axes to their home (default) positions.
     * Sends sequentially with 6-second delays:
     *   SH1-190 → 6s → SH2-240 → 6s → SH3-200 → 6s → SH4-200
     */
    void home();
};

// ─── Hand controller ────────────────────────────────────────────────────────

class HandController {
public:
    HandController();

    /**
     * Move a specific finger by the given number of steps.
     * Sends "F{finger}:{steps}" over UART1.
     *
     * @param finger  Finger number (1–6)
     * @param steps   Step count    (0–1000)
     * @return true on success, false if parameters are out of range
     */
    bool moveFinger(uint8_t finger, uint16_t steps);

    /**
     * Return all fingers to their home (zero) position.
     * Sends sequentially with 4-second delays:
     *   F1:0 → 4s → F2:0 → 4s → … → F6:0
     */
    void home();
};

// ─── Global instances (available after #include <OtterRobotics.h>) ──────────

extern OtterRoboticsClass OtterRobotics;
extern ArmController Arm;
extern HandController Hand;

#endif // OTTER_ROBOTICS_H
