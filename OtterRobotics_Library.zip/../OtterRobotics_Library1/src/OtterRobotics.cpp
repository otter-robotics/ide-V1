/*
 * OtterRobotics.cpp
 * 
 * Implementation of the Otter Robotics Arduino library.
 */

#include "OtterRobotics.h"

// ─── Global instances ────────────────────────────────────────────────────────

OtterRoboticsClass OtterRobotics;
ArmController Arm;
HandController Hand;

// ─── OtterRoboticsClass ─────────────────────────────────────────────────────

OtterRoboticsClass::OtterRoboticsClass()
    : _serial(1), _ready(false) {
}

void OtterRoboticsClass::begin(unsigned long baudRate) {
    // USB Serial (for debug / PC input)
    Serial.begin(baudRate);

    // UART1: RX = 20, TX = 21
    _serial.begin(baudRate, SERIAL_8N1, 20, 21);

    _ready = true;

    Serial.println("=== OtterRobotics ready ===");
}

HardwareSerial* OtterRoboticsClass::getSerial() {
    return &_serial;
}

bool OtterRoboticsClass::isReady() {
    return _ready;
}

// ─── ArmController ──────────────────────────────────────────────────────────

ArmController::ArmController() {
}

bool ArmController::moveAxis(uint8_t axis, uint16_t degree) {
    // Validate axis (1–4)
    if (axis < 1 || axis > 4) {
        Serial.println("[OtterRobotics] Error: axis must be 1-4");
        return false;
    }

    // Validate degree (0–360)
    if (degree > 360) {
        Serial.println("[OtterRobotics] Error: degree must be 0-360");
        return false;
    }

    if (!OtterRobotics.isReady()) {
        Serial.println("[OtterRobotics] Error: call OtterRobotics.begin() first");
        return false;
    }

    // Build command: "SH{axis}-{degree}"
    String cmd = "SH" + String(axis) + "-" + String(degree);

    OtterRobotics.getSerial()->println(cmd);

    Serial.print("[Arm] Sent: ");
    Serial.println(cmd);

    return true;
}

void ArmController::home() {
    if (!OtterRobotics.isReady()) {
        Serial.println("[OtterRobotics] Error: call OtterRobotics.begin() first");
        return;
    }

    Serial.println("[Arm] Homing all axes...");

    // SH1-190
    String cmd1 = "SH1-190";
    OtterRobotics.getSerial()->println(cmd1);
    Serial.print("[Arm] Sent: ");
    Serial.println(cmd1);
    delay(6000);

    // SH2-240
    String cmd2 = "SH2-240";
    OtterRobotics.getSerial()->println(cmd2);
    Serial.print("[Arm] Sent: ");
    Serial.println(cmd2);
    delay(6000);

    // SH3-200
    String cmd3 = "SH3-200";
    OtterRobotics.getSerial()->println(cmd3);
    Serial.print("[Arm] Sent: ");
    Serial.println(cmd3);
    delay(6000);

    // SH4-200
    String cmd4 = "SH4-200";
    OtterRobotics.getSerial()->println(cmd4);
    Serial.print("[Arm] Sent: ");
    Serial.println(cmd4);

    Serial.println("[Arm] Homing complete.");
}

// ─── HandController ─────────────────────────────────────────────────────────

HandController::HandController() {
}

bool HandController::moveFinger(uint8_t finger, uint16_t steps) {
    // Validate finger (1–6)
    if (finger < 1 || finger > 6) {
        Serial.println("[OtterRobotics] Error: finger must be 1-6");
        return false;
    }

    // Validate steps (0–1000)
    if (steps > 1000) {
        Serial.println("[OtterRobotics] Error: steps must be 0-1000");
        return false;
    }

    if (!OtterRobotics.isReady()) {
        Serial.println("[OtterRobotics] Error: call OtterRobotics.begin() first");
        return false;
    }

    // Build command: "F{finger}:{steps}"
    String cmd = "F" + String(finger) + ":" + String(steps);

    OtterRobotics.getSerial()->println(cmd);

    Serial.print("[Hand] Sent: ");
    Serial.println(cmd);

    return true;
}

void HandController::home() {
    if (!OtterRobotics.isReady()) {
        Serial.println("[OtterRobotics] Error: call OtterRobotics.begin() first");
        return;
    }

    Serial.println("[Hand] Homing all fingers...");

    for (uint8_t f = 1; f <= 6; f++) {
        String cmd = "F" + String(f) + ":0";
        OtterRobotics.getSerial()->println(cmd);
        Serial.print("[Hand] Sent: ");
        Serial.println(cmd);

        if (f < 6) {
            delay(1200);
        }
    }

    Serial.println("[Hand] Homing complete.");
}
